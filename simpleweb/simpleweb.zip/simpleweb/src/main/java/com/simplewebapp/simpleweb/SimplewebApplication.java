package com.simplewebapp.simpleweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimplewebApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimplewebApplication.class, args);
	}

}
