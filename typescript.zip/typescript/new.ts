let aname="shilpashree"
let aage=19
let aclg="pes"

console.log(aname)
console.log(aage)
console.log(aclg)

let course:any[]=["java","python"]
console.log(course)

let personal={
    name:"rabbit",
    clg:"rv",
    age:19
}
console.log(personal)

let num:number=3;
if(num>0){
    console.log("it is positive")
}

let i=19;
if(i>18){
    console.log("eligible");
}
else{
    console.log("not eligible");
}

let u=3,v=5;
if(u>v){
    console.log("u is greater")
}
else if(u<v){
    console.log("v is graeter")
}
else{
    console.log("both are equal")
}

let a=4
switch (a){
    case 1:
        console.log("first")
        break;
    case 2:
        console.log("second")
        break;
    case 3:
        console.log("third")
        break;
    default:
        console.log("wrong one")
}

function add(){
    var c=10+20;
    console.log("sum "+c)
}
add()
function addp(a:number,b:number){
    var c=a+b;
    console.log("sum :"+c)
}
addp(10,20)

