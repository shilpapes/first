let fname="shilpa"
let age=19
let clg="pes"

console.log(fname,age,clg)
console.log(typeof(fname))
console.log(typeof(age))
console.log(typeof(clg))

let course:any[]=["java","python","c++"]
console.log(course)


var personal = {
	name : "Keerthi",
	age : 20,
	status : "active"
}
console.log(personal)

let nage = 18;
if (nage>=18){
    console.log("eligible")
}
else {
    console.log("nt eligible")
}

let a=1,b=2;
if (a<b){
    console.log("a is smaller")
}
else if (a>b){
    console.log("b is greater")
}
else{
    console.log("both are equal")
}


for(var i=0;i<=10;i++){
	console.log(i);
}

//Creating a function
function add(){
    var c = 20+30;
    console.log("The Sum = "+c)
}

// call the function
add()

 function addp(a:number,b:number){
    var c = a+b;
    console.log("The Sum = "+c)
 }

 addp(30,60)
 addp(100,200)
